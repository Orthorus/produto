package modelo;

public class Produto {
	
	private int codigo;
	private String produto;
	private float valor;
	private int quantidade;
	
	public Produto(int codigo, String produto, float valor, int quantidade){
		this.codigo = codigo;
		this.produto = produto;
		this.valor = valor;
		this.quantidade = quantidade;
		
	}
	
	public Produto() {
		
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getProduto() {
		return produto;
	}

	public void setProduto(String produto) {
		this.produto = produto;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	
	
}
