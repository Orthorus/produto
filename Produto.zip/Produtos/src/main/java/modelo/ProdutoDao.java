package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import jdbc.Conexao;

public class ProdutoDao {
	
	public void cadastrar(Produto  produto) {
		
		Connection con = Conexao.obterConexao();
		
		String sql = "INSERT INTO Produto(codigo,produto,valor,quantidade) VALUES(?,?,?,?)";
		
		try {
			PreparedStatement preparador = con.prepareStatement(sql);
			preparador.setInt(1, produto.getCodigo());
			preparador.setString(2, produto.getProduto());
			preparador.setFloat(3, produto.getValor());
			preparador.setInt(4, produto.getQuantidade());
			
			
			preparador.execute();
			con.close();
			
			System.out.println("Usu�rio Cadastrado com Sucesso!!!");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	public ArrayList<Produto> mostrarTodos(){
		
		Connection con = Conexao.obterConexao();
		ArrayList<Produto> produtos = new ArrayList<>();
		String sql = "SELECT * FROM Produto";
		
		try {
			PreparedStatement preparador = con.prepareStatement(sql);
			ResultSet resultado = preparador.executeQuery();
			
			while(resultado.next()) {
				Produto produto = new Produto();
				produto.setCodigo(resultado.getInt("codigo"));
				produto.setProduto(resultado.getString("produto"));
				produto.setValor(resultado.getFloat("valor"));
				produto.setQuantidade(resultado.getInt("quantidade"));
				
				produtos.add(produto);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return produtos;
	}
	
	
	
}
