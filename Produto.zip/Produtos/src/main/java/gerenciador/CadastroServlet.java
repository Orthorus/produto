package gerenciador;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import modelo.Produto;
import modelo.ProdutoDao;

@WebServlet("/cadastro")
public class CadastroServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int codigo = Integer.parseInt(request.getParameter("txtcodigo"));
		String produto = request.getParameter("txtproduto");
		Float valor = Float.parseFloat(request.getParameter("txtvalor"));
		int quantidade = Integer.parseInt(request.getParameter("txtquantidade"));
		
		Produto produto1 = new Produto(codigo,produto,valor,quantidade); 
		
		ProdutoDao produtoDao = new ProdutoDao();
		produtoDao.cadastrar(produto1);
		response.sendRedirect("mostrar");
		

		
	}

}
